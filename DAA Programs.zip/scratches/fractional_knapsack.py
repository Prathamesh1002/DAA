def fractional_knapsack(weights, values, capacity):
    items = list(zip(weights, values))
    items.sort(key=lambda x: x[1] / x[0], reverse=True)

    total_value = 0
    knapsack = []
    for weight, value in items:
        if capacity >= weight:
            knapsack.append((weight, value))
            total_value += value
            capacity -= weight
        else:
            fraction = capacity / weight
            knapsack.append((weight * fraction, value * fraction))
            total_value += value * fraction
            break

    print("Items selected in the knapsack:")
    for item in knapsack:
        print(f"Weight: {item[0]}, Value: {item[1]}")
    print(f"Total value in the knapsack: {total_value}")


if __name__ == "__main__":
    weights = [10, 20, 30]
    values = [60, 100, 120]
    capacity = 50

    print("Fractional Knapsack Problem Solution:")
    fractional_knapsack(weights, values, capacity)
